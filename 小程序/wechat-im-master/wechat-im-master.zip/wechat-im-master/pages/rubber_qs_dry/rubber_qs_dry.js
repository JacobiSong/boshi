// pages/questionnaire/questionnaire.js
import IMOperator from "../chat/im-operator.js";
import MsgManager from "../chat/msg-type/text-manager.js";
Page({

	/**
	 * 页面的初始数据
	 */
	data: {

		// 调查结果变量



		// 三、脱水干燥
		productionCapacityDry: null, //生产能力
		surfaceSpray: null,   //物料表面喷涂
		removeMist: null,     //前端排雾设备
		exhaustSystem: null,  //干燥箱排风系统
		dewatering: null, //脱水筛出料含水率
		extrusion: null,  //挤压脱水机出料含水率
		swell: null,      //膨胀干燥机出料含水率
		unibody: null,    //挤压膨胀一体机出料含水率
		dryOven: null,    //干燥箱出料含水率
		otherInfo: null,   //其他（请说明）






		// 页面 变量
		materielStatusShow: false,
		materielStatusList: ['--', '颗粒状', '粉状', '超粉状', '片状', '晶体'],
		fluidityShow: false,
		fluidityList: ['--', '好', '一般', '差'],
		staElecShow: false,
		staElecList: ['--', '强', '弱', '无'],
		causticityShow: false,
		hygroscopicShow: false,
		toxicityShow: false,
		causticityList: ['--', '否', '弱', '中', '强'],
		adhesionShow: false,
		adhesionList: ['--', '否', '弱', '中', '强', '结块'],
		contactMaterialShow: false,
		contactMaterialList: ['--', 'SS304', 'SS316', 'SS316L', '其他'],
		envTempShow: false,
		envTempList: ['--', '5ºC~40ºC', '-20ºC~40ºC', '其他温度'],
		otherTempPlaceholder: "请先选择环境温度",
		otherTempDisabled: true,
		dangerAreaShow: false,
		dangerAreaList: ['--', '非防爆区', '粉尘防爆区', '气体防爆区'],
		subDangerAreaLabel: '具体防爆区域',
		subDangerAreaPlaceholder: '请先选择危险区域',
		subDangerAreaDisabled: true,
		otherDangerAreaShow: false,
		otherDangerAreaList: ['--', '污染会影响产品质量', '含油性会影响橡胶的化学性能'],
		surfaceSprayPopupShow: false,
		surfaceSprayList: ['--', '聚四氟乙烯', '氟化乙丙烯', '无'],
		removeMistPopupShow: false,
		exhaustSystemPopupShow: false,
		removeMistList: ['--', '风机+全套管路', '风机+调节阀', '调节阀', '无'],
		briquettingSizePopupShow: false,
		briquettingSizeList: ['--', '680x340x140（长x宽x高,mm）', '680x340x210（长x宽x高,mm）', '其他'],
		subBriquettingSizePlaceholder: "请选择压块尺寸",
		subBriquettingSizeDisabled: true,
		briquettingWeightPopupShow: false,
		briquettingWeightList: ['--', '25公斤', '35公斤', '其他'],
		subBriquettingWeightPlaceholder: "请选择压块重量",
		subBriquettingWeightDisabled: true, 
		packFormPopupShow:false, 
		packFormList: ['--','薄膜包装+装袋+装箱+码垛','薄膜包装+装袋+码垛','薄膜包装+装袋+装箱','薄膜包装+装箱', '其他'],
		subPackFormPlaceholder: "请选择包装码垛形式",
		subPackFormDisabled: true, 

	},

	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function (options) {
    this.msgManager = new MsgManager(this);
		this.imOperator = new IMOperator(this, {});
		this.send = JSON.parse(options.data);
		// console.log(this.send)
		var that = this
		wx.getStorage({
			key: 'rubber_dry',
			success(res){
				var data = JSON.parse(res.data)
				that.setData({
					productionCapacityDry:data['生产能力'], //生产能力
					surfaceSpray:data['物料表面喷涂'],   //物料表面喷涂
					removeMist:data['前端排雾设备'],    //前端排雾设备
					exhaustSystem:data['干燥箱排风系统'],//干燥箱排风系统
					dewatering:data['脱水筛出料含水率'], //脱水筛出料含水率
					extrusion:data['挤压脱水机出料含水率'],  //挤压脱水机出料含水率
					swell:data['膨胀干燥机出料含水率'],      //膨胀干燥机出料含水率
					unibody:data['挤压膨胀一体机出料含水率'],   //挤压膨胀一体机出料含水率
					dryOven:data['干燥箱出料含水率'],    //干燥箱出料含水率
					otherInfo:data['其他']   //其他（请说明）
				})
			}
		})
	},

	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady: function () {

	},

	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow: function () {

	},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide: function () {

	},

	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload: function () {

	},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh: function () {

	},

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom: function () {

	},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage: function () {

	},

	ShowPopup(event) {
		// this.setData({
		// 	fluidityShow: true
		// });
		const { key } = event.currentTarget.dataset;
    this.setData({
      [key]: true,
    });
	},

	OnClose(event) {
		const { key } = event.currentTarget.dataset;
    this.setData({
      [key]: false,
    });
	},

	PickerOnChange(event) {
		const {
			picker,
			value,
			index
		} = event.detail;
		const { key } = event.currentTarget.dataset;
    this.setData({
      [key]: value,
    });
	},

	FieldOnChange(event){
		const { key } = event.currentTarget.dataset;
    this.setData({
      [key]: event.detail,
    });
	},

	envTempOnChange(event) {
		const {
			picker,
			value,
			index
		} = event.detail;
		this.setData({
			envTempRange: value
		});
		if (value == '其他温度') {
			this.setData({
				otherTempDisabled: false,
				otherTempPlaceholder: "请输入其他温度（数字）",
				otherTemp: null,
			});
		} else {
			this.setData({
				otherTempDisabled: true,
				otherTempPlaceholder: "此项不必填写",
				otherTemp: null,
			});
		};
	},


	dangerAreaOnChange(event) {
		const {
			picker,
			value,
			index
		} = event.detail;
		this.setData({
			dangerArea: value
		});
		if (value == '粉尘防爆区' || value == '气体防爆区') {
			this.setData({
				subDangerAreaDisabled: false,
				subDangerAreaLabel: value,
				subDangerAreaPlaceholder: "请输入具体区域（区域号）",
				subDangerArea: null,
			});
		} else if (value == '非防爆区') {
			this.setData({
				subDangerAreaPlaceholder: "非防爆区不必填写",
				subDangerAreaDisabled: true,
				subDangerArea: null,
				subDangerAreaLabel: "具体防爆区域"
			});
		} else if (value == '--') {
			this.setData({
				subDangerAreaPlaceholder: "无防爆区不必填写",
				subDangerAreaDisabled: true,
				subDangerArea: null,
				subDangerAreaLabel: "具体防爆区域"
			});
		}
	},


	briquettingSizeOnChange(event) {
		const { picker, value, index } = event.detail;
		this.setData({ briquettingSize: value });
		if (value == '其他') {
			this.setData({
				subBriquettingSizeDisabled: false,
				subBriquettingSizePlaceholder: "请输入尺寸（长x宽x高,mm）",
				subBriquettingSize: null,
			});
		} else {
			this.setData({
				subBriquettingSizePlaceholder: "已选择尺寸，不必填写",
				subBriquettingSizeDisabled: true,
				subBriquettingSize: null,
			});
		}
	},


	briquettingWeightOnChange(event){
		const {picker, value, index} = event.detail;
		this.setData({briquettingWeight: value});
		if (value == '其他') {
			this.setData({
				subBriquettingWeightDisabled: false,
				subBriquettingWeightPlaceholder: "请输入重量（公斤）",
				subBriquettingWeight: null,
			});
		} else {
			this.setData({
				subBriquettingWeightPlaceholder: "已选择重量，不必填写",
				subBriquettingWeightDisabled: true,
				subBriquettingWeight: null,
			});
		}
	},


	packFormOnChange(event){
		const { picker, value, index} = event.detail;
		this.setData({packForm: value});
		if (value == '其他') {
			this.setData({
				subPackFormDisabled: false,
				subPackFormPlaceholder: "包装码垛形式",
				subPackForm: null,
			});
		} else {
			this.setData({
				subPackFormPlaceholder: "已选择具体包装码垛形式，不必填写",
				subPackFormDisabled: true,
				subPackForm: null,
			});
		}
	},
	
	async sendMsg({content, itemIndex}) {
    try {
        const {msg} = await this.imOperator.onSimulateSendMsg({content})
        console.log(msg)
        return {msg};
    } catch (e) {
        console.log(e);
    }
},

	submitButtonOnClick() {
		// var content = {key:'rubber-info2', value:this.data}
		// this.msgManager.sendOneMsg({type:"user-info", content});
	this.send['生产能力'] = this.data.productionCapacityDry //生产能力
  this.send['物料表面喷涂'] = this.data.surfaceSpray   //物料表面喷涂
  this.send['前端排雾设备'] = this.data.removeMist    //前端排雾设备
  this.send['干燥箱排风系统'] = this.data.exhaustSystem  //干燥箱排风系统
  this.send['脱水筛出料含水率'] = this.data.dewatering //脱水筛出料含水率
  this.send['挤压脱水机出料含水率'] = this.data.extrusion  //挤压脱水机出料含水率
  this.send['膨胀干燥机出料含水率'] = this.data.swell      //膨胀干燥机出料含水率
  this.send['挤压膨胀一体机出料含水率'] = this.data.unibody   //挤压膨胀一体机出料含水率
  this.send['干燥箱出料含水率'] = this.data.dryOven    //干燥箱出料含水率
	this.send['其他'] = this.data.otherInfo   //其他（请说明）

	wx.setStorage({
		data: JSON.stringify(this.send),
		key: 'rubber_dry',
	})
	var content = {key:'rubber-info', value:this.send}
  this.msgManager.sendOneMsg({type:"user-info", content});
	wx.reLaunch({
		url: '../../pages/menu1/menu1?data='+JSON.stringify(this.send)
	})
	},

})