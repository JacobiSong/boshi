// pages/questionnaire/questionnaire.js
import IMOperator from "../chat/im-operator.js";
import MsgManager from "../chat/msg-type/text-manager.js";
Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 调查结果变量
    otherBag: null,
    subOtherBag: null,
    quantity: null,
    packBag: null,
    loadBag: null,
    palletizingLayers: null,
    palletizingForm: null,


    // 页面 变量
    wovenBagPopupShow: false,
    wovenBagList: ['--', '枕式内涂膜塑料编织袋', '枕式外涂膜塑料编织袋', 'M形内涂膜塑料编织袋', 'M形外涂膜塑料编织袋', '内衬膜外涂膜塑料编织袋 （内外袋口不粘合）', '内衬膜外涂膜塑料编织袋（内外袋口缝合或粘合在一起）'],
    poperBagPopupShow: false,
    paperBagList: ['--', '枕式牛皮纸袋', '信封袋', 'M形牛皮纸袋', '内衬膜M形牛皮纸袋（内外袋口不粘和在一起）', '内衬膜M形牛皮纸袋（内外袋口缝合或粘合在一起）'],
    otherBagPopupShow: false,
    otherBagList: ['--', '重膜袋', '麻袋', '特殊料袋'],
    subOtherBagLabel: "特殊料袋种类",
    subOtherBagPlaceholder: "请先选择其他袋种类",
    subOtherBagDisabled: true,
    sealingPopupShow: false,
    sealingList: ['--', '手工扎口', '折边缝口', '缝口+粘纸带热封', '内衬膜热封+外袋缝纸条', '内衬膜热封+外袋折边缝口', '内衬膜热封+袋舌折边热封（只适用信封袋）', '内衬膜热封+外袋缝口+粘纸带热封', '重膜袋热封', '重膜袋热封', '内衬膜热封+内外袋折边缝口'],
    palletizingLayersPopupShow: false,
    palletizingLayersList: ['--', '8层', '10层', '12层', '其他'],
    palletizingFormPopupShow: false,
    palletizingFormList: ['--', '高架码垛', '机器人码垛', '低架码垛', '人工码垛', '自动装车'],


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
	this.msgManager = new MsgManager(this);
    this.imOperator = new IMOperator(this, {});
    this.send = JSON.parse(options.data);
    var that = this
    wx.getStorage({
      key: 'powder_cr',
      success(res){
        var data = JSON.parse(res.data);
        that.setData({
          otherBag:data['包装袋'],
          subOtherBag:data['其他袋'],
          quantity:data['袋装规格'],
          packBag:data['包装能力'],
          loadBag:data['码垛能力'],
          palletizingLayers:data['码垛层数'],
          palletizingForm:data['码垛形式']
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  
  wovenBagPopup() {
    this.setData({
      wovenBagPopupShow: true
    });
  },

  wovenBagOnClose() {
    this.setData({
      wovenBagPopupShow: false
    });
  },

  wovenBagOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      wovenBag: value
    });
  },

  paperBagPopup() {
    this.setData({
      paperBagPopupShow: true
    });
  },
  paperBagOnClose() {
    this.setData({
      paperBagPopupShow: false
    });
  },
  paperBagOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      paperBag: value
    });
  },

  otherBagPopup() {
    this.setData({
      otherBagPopupShow: true
    });
  },
  otherBagOnClose() {
    this.setData({
      otherBagPopupShow: false
    });
  },
  otherBagOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      otherBag: value
    });

    if (value == '特殊料袋') {
      this.setData({
        subOtherBagDisabled: false,
        subOtherBagLabel: value,
        subOtherBagPlaceholder: "请输入特殊料袋种类"
      });
    } else if (value == '重膜袋' || value == '麻袋') {
      this.setData({
        subOtherBagPlaceholder: "不必填写",
        subOtherBagDisabled: true,
        subOtherBag: null,
        subOtherBagLabel: "特殊料袋种类"
      });
    } else if (value == '--') {
      this.setData({
        subOtherBagPlaceholder: "无其他料袋不必填写",
        subOtherBagDisabled: true,
        subOtherBag: null,
        subOtherBagLabel: "无其他料袋"
      });
    }
  },
  subOtherBagOnChange(event) {
    this.setData({
      subOtherBag: event.detail
    });
  },

  sealingPopup() {
    this.setData({
      sealingPopupShow: true
    });
  },

  sealingOnClose() {
    this.setData({
      sealingPopupShow: false
    });
  },

  sealingOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      sealing: value
    });
  },

  quantityOnChange(event){
    this.setData({
      quantity: event.detail
    });
  },
  packBagOnChange(event){
    this.setData({
      packBag: event.detail
    });
  },

  loadBagOnChange(event) {
    this.setData({
      loadBag: event.detail
    });
  },

  palletizingLayersPopup() {
    this.setData({
      palletizingLayersPopupShow: true
    });
  },
  palletizingLayersOnClose() {
    this.setData({
      palletizingLayersPopupShow: false
    });
  },
  palletizingLayersOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      palletizingLayers: value
    });
  },

  palletizingFormPopup() {
    this.setData({
      palletizingFormPopupShow: true
    });
  },
  palletizingFormOnClose() {
    this.setData({
      palletizingFormPopupShow: false
    });
  },
  palletizingFormOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      palletizingForm: value
    });
  },
  
   async sendMsg({content, itemIndex}) {
    try {
        const {msg} = await this.imOperator.onSimulateSendMsg({content})
        console.log(msg)
        return {msg};
    } catch (e) {
        console.log(e);
    }
  },
  
  submitButtonOnClick(){
    this.send['包装袋'] = this.data.otherBag
    this.send['其他袋'] = this.data.subOtherBag
    this.send['袋装规格'] =  this.data.quantity
    this.send['包装能力'] =  this.data.packBag
    this.send['码垛能力'] = this.data.loadBag
    this.send['码垛层数'] = this.data.palletizingLayers
    this.send['码垛形式'] = this.data.palletizingForm
    wx.setStorage({
      data: JSON.stringify(this.send),
      key: 'powder_cr',
    })
    var content = {'key':'powder-info', 'value':this.send}
    this.msgManager.sendOneMsg({type:"user-info", content});
    wx.navigateTo({
      url: '../../pages/menu2/menu2?data='+JSON.stringify(this.send),
      // url: '../../pages/chat/chat'
		})

  },

})