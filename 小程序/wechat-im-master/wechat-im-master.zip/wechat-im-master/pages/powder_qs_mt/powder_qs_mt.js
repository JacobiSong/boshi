// pages/questionnaire/questionnaire.js
import IMOperator from "../chat/im-operator.js";
import MsgManager from "../chat/msg-type/text-manager.js";
Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 调查结果变量
    materielName: null,
    bulkDensity: null,
    realDensity: null,
    temperature: null,
    degree: null,
    materielStatus: null,
    fluidity: null,
    staElec: null,
    causticity: null,
    hygroscopic: null,
    adhesion: null,
    toxicity: null,
    form: null,
    envTempRange: null,
    subDangerArea: null,

    // 页面 变量
    materielStatusShow: false,
    materielStatusList: ['--', '颗粒状', '粉状', '超粉状', '片状', '晶体'],
    fluidityShow: false,
    fluidityList: ['--', '好', '一般', '差'],
    staElecShow: false,
    staElecList: ['--', '强', '弱', '无'],
    causticityShow: false,
    hygroscopicShow: false,
    toxicityShow: false,
    causticityList: ['--', '否', '弱', '中', '强'],
    adhesionShow: false,
    adhesionList: ['--', '否', '弱', '中', '强', '结块'],
    formShow: false,
    formList: ['--', '螺旋', '皮带', '振动', '重力'],
    envTempShow: false,
    envTempList: ['--', '5ºC~40ºC', '-20ºC~40ºC'],
    dangerAreaShow: false,
    dangerAreaList: ['--', '非防爆区', '粉尘防爆区', '气体防爆区'],
    subDangerAreaLabel: '具体防爆区域',
    subDangerAreaPlaceholder: '请先选择危险区域',
    subDangerAreaDisabled: true,


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.msgManager = new MsgManager(this);
    this.imOperator = new IMOperator(this, {});
    this.send = JSON.parse(options.data)
    var that = this
    wx.getStorage({
      key: 'powder_mt',
      success (res) {
        var data = JSON.parse(res.data);
        //let that = this
        that.setData({
          materielName:data['物料名称'],
          bulkDensity:data['堆积密度'],
          realDensity:data['实密度'],
          temperature:data['包装物料温度'],
          degree:data['安息角度'],
          materielStatus:data['物料状态'],
          fluidity:data['流动性'],
          staElec:data['静电'],
          causticity:data['腐蚀性'],
          hygroscopic:data['吸湿性'],
          adhesion:data['粘附性'],
          toxicity:data['毒性'],
          form:data['给料形式'],
          envTempRange:data['环境温度'],
          dangerArea:data['危险区域'],
          subDangerArea:data['危险区域区域号']
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  materielStatusShowPopup() {
    this.setData({
      materielStatusShow: true
    });
  },

  materielStatusOnClose() {
    this.setData({
      materielStatusShow: false
    });
  },


  materielStatusPickerOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      materielStatus: value,
    });
  },

  fluidityShowPopup() {
    this.setData({
      fluidityShow: true
    });
  },

  fluidityOnClose() {
    this.setData({
      fluidityShow: false
    });
  },

  fluidityPickerOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      fluidity: value,
    });
  },

  staElecShowPopup() {
    this.setData({
      staElecShow: true
    });
  },

  staElecOnClose() {
    this.setData({
      staElecShow: false
    });
  },

  staElecOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      staElec: value
    });
  },

  causticityShowPopup() {
    this.setData({
      causticityShow: true
    });
  },

  causticityOnClose() {
    this.setData({
      causticityShow: false
    });
  },

  causticityOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      causticity: value
    });
  },

  hygroscopicShowPopup() {
    this.setData({
      hygroscopicShow: true
    });
  },

  hygroscopicOnClose() {
    this.setData({
      hygroscopicShow: false
    });
  },

  hygroscopicOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      hygroscopic: value
    });
  },

  adhesionShowPopup() {
    this.setData({
      adhesionShow: true
    });
  },

  adhesionOnClose() {
    this.setData({
      adhesionShow: false
    });
  },

  adhesionOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      adhesion: value
    });
  },

  toxicityShowPopup() {
    this.setData({
      toxicityShow: true
    });
  },

  toxicityOnClose() {
    this.setData({
      toxicityShow: false
    });
  },

  toxicityOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      toxicity: value
    });
  },

  formShowPopup() {
    this.setData({
      formShow: true
    });
  },

  formOnClose() {
    this.setData({
      formShow: false
    });
  },

  formOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      form: value
    });
  },

  envTempPopup() {
    this.setData({
      envTempShow: true
    });
  },

  envTempOnClose() {
    this.setData({
      envTempShow: false
    });
  },

  envTempOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      envTempRange: value
    });
  },

  dangerAreaPopup() {
    this.setData({
      dangerAreaShow: true
    });
  },

  dangerAreaOnClose() {
    this.setData({
      dangerAreaShow: false
    });
  },

  dangerAreaOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      dangerArea: value
    });
    if (value == '粉尘防爆区' || value == '气体防爆区') {
      this.setData({
        subDangerAreaDisabled: false,
        subDangerAreaLabel: value,
        subDangerAreaPlaceholder: "请输入具体区域（区域号）",
        subDangerArea: null,
      });
    } else if (value == '非防爆区') {
      this.setData({
        subDangerAreaPlaceholder: "非防爆区不必填写",
        subDangerAreaDisabled: true,
        subDangerArea: null,
        subDangerAreaLabel: "具体防爆区域"
      });
    } else if (value == '--') {
      this.setData({
        subDangerAreaPlaceholder: "无防爆区不必填写",
        subDangerAreaDisabled: true,
        subDangerArea: null,
        subDangerAreaLabel: "具体防爆区域"
      });
    }
  },

  subDangerAreaOnChange(event) {
    this.setData({
      subDangerArea: event.detail
    });
  },

  async sendMsg({content, itemIndex}) {
    try {
        const {msg} = await this.imOperator.onSimulateSendMsg({content})
        console.log(msg)
        return {msg};
    } catch (e) {
        console.log(e);
    }
  },
  
  submitButtonOnClick(){
    this.send['物料名称'] = this.data.materielName,
    this.send['堆积密度'] = this.data.bulkDensity,
    this.send['实密度'] = this.data.realDensity,
    this.send['包装物料温度'] = this.data.temperature,
    this.send['安息角度'] = this.data.degree,
    this.send['物料状态'] = this.data.materielStatus,
    this.send['流动性'] = this.data.fluidity,
    this.send['静电'] = this.data.staElec,
    this.send['腐蚀性'] = this.data.causticity,
    this.send['吸湿性'] = this.data.hygroscopic,
    this.send['粘附性'] = this.data.adhesion,
    this.send['毒性'] = this.data.toxicity,
    this.send['给料形式'] = this.data.form,
    this.send['环境温度'] = this.data.envTempRange,
    this.send['危险区域'] =  this.data.dangerArea,
    this.send['危险区域区域号'] = this.data.subDangerArea

    wx.setStorage({
      data: JSON.stringify(this.send),
      key: 'powder_mt',
    })

    var content = {key:'powder-info', value:this.send}
    this.msgManager.sendOneMsg({type:"user-info", content});
    wx.reLaunch({
      url: '../../pages/menu2/menu2?data='+JSON.stringify(this.send),
      // url: '../../pages/chat/chat'
    })
  },

})