Page(
  {

    data:{

    },
    onShow(){
      
    },

    onReady: function () {

    },
  

    onLoad:function(options){
      this.send = options.data;
      this.send = JSON.parse(this.send)
      var keys = ['物料名称', '堆积密度', '实密度', '包装物料温度', '安息角度', '物料状态', '流动性', '静电', '腐蚀性', '吸湿性', '粘附性', '毒性', '给料形式', '环境温度', '危险区域', '危险区域区域号', '包装袋', '其他袋', '袋装规格', '包装能力','码垛能力', '码垛层数', '码垛形式']
      for(var key in keys){
        if(!this.send.hasOwnProperty(keys[key])){
          this.send[keys[key]] = null
        }
      }
      this.send = JSON.stringify(this.send)
    },

    open(e){
      console.log(e)
      var url
      var id = Number(e.currentTarget.id)
      switch (id) {
        case 1:
          wx.reLaunch({
            url: '../../pages/powder_qs_mt/powder_qs_mt?data='+this.send,
          })
          break;
        case 2:
          wx.reLaunch({
            url: '../../pages/powder_qs_craft/powder_qs_craft?data='+this.send,
          })
          break
        case 3:
          wx.reLaunch({
            url: '../../pages/manual/manual',
          })
          break
        case 5:
          url = 'http://152.136.126.194/并线输送电气分册（二并一）.doc'
          break
        case 6:
          url = 'http://152.136.126.194/并线输送电气分册（三并一）.doc'
          break
        case 7:
          url = 'http://152.136.126.194/单摆臂包装电气分册.doc'
          break
        case 8:
          url = 'http://152.136.126.194/单抓单码(装箱)电气分册.doc'
          break
        case 9:
          url = 'http://152.136.126.194/单抓单码电气分册(第二版).doc'
          break
        case 10:
          url = 'http://152.136.126.194/低位码垛电气分册.doc'
          break
        case 11:
          url = 'http://152.136.126.194/封口机.doc'
          break
        case 12:
          url = 'http://152.136.126.194/拉伸套膜电气分册.doc'
          break
        case 13:
          url = 'http://152.136.126.194/输送检测电气分册.doc'
          break
        case 14:
          url = 'http://152.136.126.194/小车横进包装电气分册.doc'
          break
        default:
          break;
      }
    }  
  },
 )