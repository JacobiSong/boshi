// pages/questionnaire/questionnaire.js
import IMOperator from "../chat/im-operator.js";
import MsgManager from "../chat/msg-type/text-manager.js";
var data = {}

Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 调查结果变量
    companyName: null,
    userName: null,
    phone: null,
    deviceID: null,
    province: null,
    city: null,
    materielName: null,
    bulkDensity: null,
    realDensity: null,
    temperature: null,
    degree: null,
    materielStatus: null,
    fluidity: null,
    staElec: null,
    causticity: null,
    hygroscopic: null,
    adhesion: null,
    toxicity: null,
    form: null,
    envTempRange: null,
    subDangerArea: null,
    wovenBag: null,
    paperBag: null,
    otherBag: null,
    subOtherBag: null,
    sealing: null,
    quantityPerBag: null,
    quantityPerBox: null,
    quantityPerBucket: null,
    packBagPerHour: null,
    packBoxPerHour: null,
    packBucketPerHour: null,
    loadBagPerHour: null,
    loadBoxPerHour: null,
    loadBucketPerHour: null,
    palletizingLayers: null,
    palletizingForm: null,


    // 页面 变量
    materielStatusShow: false,
    materielStatusList: ['--', '颗粒状', '粉状', '超粉状', '片状', '晶体'],
    fluidityShow: false,
    fluidityList: ['--', '好', '一般', '差'],
    staElecShow: false,
    staElecList: ['--', '强', '弱', '无'],
    causticityShow: false,
    hygroscopicShow: false,
    toxicityShow: false,
    causticityList: ['--', '否', '弱', '中', '强'],
    adhesionShow: false,
    adhesionList: ['--', '否', '弱', '中', '强', '结块'],
    formShow: false,
    formList: ['--', '螺旋', '皮带', '振动', '重力'],
    envTempShow: false,
    envTempList: ['--', '5ºC~40ºC', '-20ºC~40ºC'],
    dangerAreaShow: false,
    dangerAreaList: ['--', '非防爆区', '粉尘防爆区', '气体防爆区'],
    subDangerAreaLabel: '具体防爆区域',
    subDangerAreaPlaceholder: '请先选择危险区域',
    subDangerAreaDisabled: true,
    wovenBagPopupShow: false,
    wovenBagList: ['--', '枕式内涂膜塑料编织袋', '枕式外涂膜塑料编织袋', 'M形内涂膜塑料编织袋', 'M形外涂膜塑料编织袋', '内衬膜外涂膜塑料编织袋 （内外袋口不粘合）', '内衬膜外涂膜塑料编织袋（内外袋口缝合或粘合在一起）'],
    poperBagPopupShow: false,
    paperBagList: ['--', '枕式牛皮纸袋', '信封袋', 'M形牛皮纸袋', '内衬膜M形牛皮纸袋（内外袋口不粘和在一起）', '内衬膜M形牛皮纸袋（内外袋口缝合或粘合在一起）'],
    otherBagPopupShow: false,
    otherBagList: ['--', '重膜袋', '麻袋', '特殊料袋'],
    subOtherBagLabel: "特殊料袋种类",
    subOtherBagPlaceholder: "请先选择其他袋种类",
    subOtherBagDisabled: true,
    sealingPopupShow: false,
    sealingList: ['--', '手工扎口', '折边缝口', '缝口+粘纸带热封', '内衬膜热封+外袋缝纸条', '内衬膜热封+外袋折边缝口', '内衬膜热封+袋舌折边热封（只适用信封袋）', '内衬膜热封+外袋缝口+粘纸带热封', '重膜袋热封', '重膜袋热封', '内衬膜热封+内外袋折边缝口'],
    palletizingLayersPopupShow: false,
    palletizingLayersList: ['--', '8层', '10层', '12层', '其他'],
    palletizingFormPopupShow: false,
    palletizingFormList: ['--', '高架码垛', '机器人码垛', '低架码垛', '人工码垛', '自动装车'],


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
     this.msgManager = new MsgManager(this);
     this.imOperator = new IMOperator(this, {});
     this.setData({
        companyName: data['companyName'],
        userName: data['userName'],
        phone: data['phone'],
        deviceID: data['deviceID'],
        province: data['province'],
        city: data['city'],
        materielName: data['materielName'],
        bulkDensity: data['bulkDensity'],
        realDensity: data['realDensity'],
        temperature: data['temperature'],
        degree: data['degree'],
        materielStatus: data['materielStatus'],
        fluidity: data['fluidity'],
        staElec: data['staElec'],
        causticity: data['causticity'],
        hygroscopic: data['hygroscopic'],
        adhesion: data['adhesion'],
        toxicity: data['toxicity'],
        form: data['form'],
        envTempRange: data['envTempRange'],
        subDangerArea: data['subDangerArea'],
        wovenBag: data['wovenBag'],
        paperBag: data['paperBag'],
        otherBag: data['otherBag'],
        subOtherBag: data['subOtherBag'],
        sealing: data['sealing'],
        quantityPerBag: data['quantityPerBag'],
        quantityPerBox: data['quantityPerBox'],
        quantityPerBucket: data['quantityPerBucket'],
        packBagPerHour: data['packBagPerHour'],
        packBoxPerHour: data['packBoxPerHour'],
        packBucketPerHour: data['packBucketPerHour'],
        loadBagPerHour: data['loadBagPerHour'],
        loadBoxPerHour: data['loadBoxPerHour'],
        loadBucketPerHour: data['loadBucketPerHour'],
        palletizingLayers: data['palletizingLayers'],
        palletizingForm: data['palletizingForm'],
     })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  materielStatusShowPopup() {
    this.setData({
      materielStatusShow: true
    });
  },

  materielStatusOnClose() {
    this.setData({
      materielStatusShow: false
    });
  },


  materielStatusPickerOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      materielStatus: value,
    });
  },

  fluidityShowPopup() {
    this.setData({
      fluidityShow: true
    });
  },

  fluidityOnClose() {
    this.setData({
      fluidityShow: false
    });
  },

  fluidityPickerOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      fluidity: value,
    });
  },

  staElecShowPopup() {
    this.setData({
      staElecShow: true
    });
  },

  staElecOnClose() {
    this.setData({
      staElecShow: false
    });
  },

  staElecOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      staElec: value
    });
  },

  causticityShowPopup() {
    this.setData({
      causticityShow: true
    });
  },

  causticityOnClose() {
    this.setData({
      causticityShow: false
    });
  },

  causticityOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      causticity: value
    });
  },

  hygroscopicShowPopup() {
    this.setData({
      hygroscopicShow: true
    });
  },

  hygroscopicOnClose() {
    this.setData({
      hygroscopicShow: false
    });
  },

  hygroscopicOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      hygroscopic: value
    });
  },

  adhesionShowPopup() {
    this.setData({
      adhesionShow: true
    });
  },

  adhesionOnClose() {
    this.setData({
      adhesionShow: false
    });
  },

  adhesionOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      adhesion: value
    });
  },

  toxicityShowPopup() {
    this.setData({
      toxicityShow: true
    });
  },

  toxicityOnClose() {
    this.setData({
      toxicityShow: false
    });
  },

  toxicityOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      toxicity: value
    });
  },

  formShowPopup() {
    this.setData({
      formShow: true
    });
  },

  formOnClose() {
    this.setData({
      formShow: false
    });
  },

  formOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      form: value
    });
  },

  envTempPopup() {
    this.setData({
      envTempShow: true
    });
  },

  envTempOnClose() {
    this.setData({
      envTempShow: false
    });
  },

  envTempOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      envTempRange: value
    });
  },

  dangerAreaPopup() {
    this.setData({
      dangerAreaShow: true
    });
  },

  dangerAreaOnClose() {
    this.setData({
      dangerAreaShow: false
    });
  },

  dangerAreaOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      dangerArea: value
    });
    if (value == '粉尘防爆区' || value == '气体防爆区') {
      this.setData({
        subDangerAreaDisabled: false,
        subDangerAreaLabel: value,
        subDangerAreaPlaceholder: "请输入具体区域（区域号）",
        subDangerArea: null,
      });
    } else if (value == '非防爆区') {
      this.setData({
        subDangerAreaPlaceholder: "非防爆区不必填写",
        subDangerAreaDisabled: true,
        subDangerArea: null,
        subDangerAreaLabel: "具体防爆区域"
      });
    } else if (value == '--') {
      this.setData({
        subDangerAreaPlaceholder: "无防爆区不必填写",
        subDangerAreaDisabled: true,
        subDangerArea: null,
        subDangerAreaLabel: "具体防爆区域"
      });
    }
  },

  subDangerAreaOnChange(event) {
    this.setData({
      subDangerArea: event.detail
    });
  },

  wovenBagPopup() {
    this.setData({
      wovenBagPopupShow: true
    });
  },

  wovenBagOnClose() {
    this.setData({
      wovenBagPopupShow: false
    });
  },

  wovenBagOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      wovenBag: value
    });
  },

  paperBagPopup() {
    this.setData({
      paperBagPopupShow: true
    });
  },
  paperBagOnClose() {
    this.setData({
      paperBagPopupShow: false
    });
  },
  paperBagOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      paperBag: value
    });
  },

  otherBagPopup() {
    this.setData({
      otherBagPopupShow: true
    });
  },
  otherBagOnClose() {
    this.setData({
      otherBagPopupShow: false
    });
  },
  otherBagOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      otherBag: value
    });

    if (value == '特殊料袋') {
      this.setData({
        subOtherBagDisabled: false,
        subOtherBagLabel: value,
        subOtherBagPlaceholder: "请输入特殊料袋种类"
      });
    } else if (value == '重膜袋' || value == '麻袋') {
      this.setData({
        subOtherBagPlaceholder: "不必填写",
        subOtherBagDisabled: true,
        subOtherBag: null,
        subOtherBagLabel: "特殊料袋种类"
      });
    } else if (value == '--') {
      this.setData({
        subOtherBagPlaceholder: "无其他料袋不必填写",
        subOtherBagDisabled: true,
        subOtherBag: null,
        subOtherBagLabel: "无其他料袋"
      });
    }
  },
  subOtherBagOnChange(event) {
    this.setData({
      subOtherBag: event.detail
    });
  },

  sealingPopup() {
    this.setData({
      sealingPopupShow: true
    });
  },

  sealingOnClose() {
    this.setData({
      sealingPopupShow: false
    });
  },

  sealingOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      sealing: value
    });
  },

  quantityPerBagOnChange(event) {
    this.setData({
      quantityPerBag: event.detail
    });
  },
  quantityPerBoxOnChange(event) {
    this.setData({
      quantityPerBox: event.detail
    });
  },
  quantityPerBucketOnChange(event) {
    this.setData({
      quantityPerBucket: event.detail
    });
  },

  packBagPerHourOnChange(event) {
    this.setData({
      packBagPerHour: event.detail
    });
  },

  packBoxPerHourOnChange(event) {
    this.setData({
      packBoxPerHour: event.detail
    });
  },

  packBucketPerHourOnChange(event) {
    this.setData({
      packBucketPerHour: event.detail
    });
  },

  loadBagPerHourOnChange(event) {
    this.setData({
      loadBagPerHour: event.detail
    });
  },

  loadBoxPerHourOnChange(event) {
    this.setData({
      loadBoxPerHour: event.detail
    });
  },

  loadBucketPerHourOnChange(event) {
    this.setData({
      loadBucketPerHour: event.detail
    });
  },


  palletizingLayersPopup() {
    this.setData({
      palletizingLayersPopupShow: true
    });
  },
  palletizingLayersOnClose() {
    this.setData({
      palletizingLayersPopupShow: false
    });
  },
  palletizingLayersOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      palletizingLayers: value
    });
  },

  palletizingFormPopup() {
    this.setData({
      palletizingFormPopupShow: true
    });
  },
  palletizingFormOnClose() {
    this.setData({
      palletizingFormPopupShow: false
    });
  },
  palletizingFormOnChange(event) {
    const {
      picker,
      value,
      index
    } = event.detail;
    this.setData({
      palletizingForm: value
    });
  },
  
  async sendMsg({content, itemIndex}) {
    try {
        const {msg} = await this.imOperator.onSimulateSendMsg({content})
        console.log(msg)
        return {msg};
    } catch (e) {
        console.log(e);
    }
},

  submitButtonOnClick(){
    data['product'] = 0
    data['companyName'] = this.data.companyName
    data['userName'] = this.data.userName
    data['phone'] = this.data.phone
    data['deviceID'] = this.data.deviceID
    data['province'] = this.data.province
    data['city'] = this.data.city
    data['materielName'] = this.data. materielName
    data['bulkDensity'] = this.data. bulkDensity
    data['realDensity'] = this.data. realDensity
    data['temperature'] = this.data. temperature
    data['degree'] = this.data.degree
    data['materielStatus'] = this.data. materielStatus
    data['fluidity'] = this.data.fluidity
    data['staElec'] = this.data.staElec
    data['causticity'] = this.data.causticity
    data['hygroscopic'] = this.data.hygroscopic
    data['adhesion'] = this.data.adhesion
    data['toxicity'] = this.data.toxicity
    data['form'] = this.data.form
    data['envTempRange'] = this.data.envTempRange
    data['subDangerArea'] = this.data.subDangerArea
    data['wovenBag'] = this.data.wovenBag
    data['paperBag'] = this.data.paperBag
    data['otherBag'] = this.data.otherBag
    data['subOtherBag'] = this.data.subOtherBag
    data['sealing'] = this.data.sealing
    data['quantityPerBag'] = this.data.quantityPerBag
    data['quantityPerBox'] = this.data.quantityPerBox
    data['quantityPerBucket'] = this.data.quantityPerBucket
    data['packBagPerHour'] = this.data.packBagPerHour
    data['packBoxPerHour'] = this.data.packBoxPerHour
    data['packBucketPerHour'] = this.data.packBucketPerHour
    data['loadBagPerHour'] = this.data.loadBagPerHour
    data['loadBoxPerHour'] = this.data.loadBoxPerHour
    data['loadBucketPerHour'] = this.data.loadBucketPerHour
    data['palletizingLayers'] = this.data.palletizingLayers
    data['palletizingForm'] = this.data.palletizingForm
    if(this.data.companyName && this.data.userName && this.data.phone){
      var content = {key:'info', value:data}
      this.msgManager.sendOneMsg({type:"user-info", content});
      wx.reLaunch({
        url: '../../pages/chat/chat',
      })
    }else{
      wx.showModal({
          title: '请填写必填字段',
          content: '请填写必填字段',
      })
    }
  },

})