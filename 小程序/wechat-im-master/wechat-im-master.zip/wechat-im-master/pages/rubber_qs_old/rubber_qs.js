// pages/questionnaire/questionnaire.js

Page({

	/**
	 * 页面的初始数据
	 */
	data: {

		// 调查结果变量

		// 一、客户信息
		companyName: null, 	//公司名称
		userName: null, 	//姓名
		phone: null,		//手机
		deviceID: null,		//项目编号
		province: null,		//设备安装地址-省
		city: null,			//设备安装地址-市

		// 二、物料参数
		materielName: null,	//物料名称	
		bulkDensity: null,	//堆积密度
		ph: null,			//PH值
		degree: null,		//安息角度		
		fluidity: null,			//流动性
		staElec: null,			//静电
		causticity: null,		//腐蚀性
		hygroscopic: null,		//吸湿性
		adhesion: null,			//粘附性
		toxicity: null,			//毒性
		contactMaterial: null,	//接触物料材质
		envTempRange: null,		//环境温度
		otherTemp: null,		//环境温度-其他	
		dangerArea: null,		//危险区域
		subDangerArea: null,	//危险区域具体区号 
		otherDangerArea: null,	//其他危险区域

		// 三、脱水干燥
		productionCapacityDry: null, //生产能力
		surfaceSpray: null,   //物料表面喷涂
		removeMist: null,     //前端排雾设备
		exhaustSystem: null,  //干燥箱排风系统
		dewatering: null, //脱水筛出料含水率
		extrusion: null,  //挤压脱水机出料含水率
		swell: null,      //膨胀干燥机出料含水率
		unibody: null,    //挤压膨胀一体机出料含水率
		dryOven: null,    //干燥箱出料含水率
		otherInfo: null,   //其他（请说明）

		// 四、包装码垛
		productionCapacityPack: null, //生产能力
		briquettingSize: null, // 压块尺寸
		subBriquettingSize: null, // 压块尺寸-其他
		briquettingWeight: null, // 压块重量
		subBriquettingWeight: null, // 压块重量-其他
		packForm : null, //	包装码垛形式
		subPackForm: null, // 包装码垛形式-其他
		palletizingCapacity: null, //码垛能力
		packagingCapacity: null, //包装能力
		otherCapacity: null, // 设备参数-其他





		// 页面 变量
		materielStatusShow: false,
		materielStatusList: ['--', '颗粒状', '粉状', '超粉状', '片状', '晶体'],
		fluidityShow: false,
		fluidityList: ['--', '好', '一般', '差'],
		staElecShow: false,
		staElecList: ['--', '强', '弱', '无'],
		causticityShow: false,
		hygroscopicShow: false,
		toxicityShow: false,
		causticityList: ['--', '否', '弱', '中', '强'],
		adhesionShow: false,
		adhesionList: ['--', '否', '弱', '中', '强', '结块'],
		contactMaterialShow: false,
		contactMaterialList: ['--', 'SS304', 'SS316', 'SS316L', '其他'],
		envTempShow: false,
		envTempList: ['--', '5ºC~40ºC', '-20ºC~40ºC', '其他温度'],
		otherTempPlaceholder: "请先选择环境温度",
		otherTempDisabled: true,
		dangerAreaShow: false,
		dangerAreaList: ['--', '非防爆区', '粉尘防爆区', '气体防爆区'],
		subDangerAreaLabel: '具体防爆区域',
		subDangerAreaPlaceholder: '请先选择危险区域',
		subDangerAreaDisabled: true,
		otherDangerAreaShow: false,
		otherDangerAreaList: ['--', '污染会影响产品质量', '含油性会影响橡胶的化学性能'],
		surfaceSprayPopupShow: false,
		surfaceSprayList: ['--', '聚四氟乙烯', '氟化乙丙烯', '无'],
		removeMistPopupShow: false,
		exhaustSystemPopupShow: false,
		removeMistList: ['--', '风机+全套管路', '风机+调节阀', '调节阀', '无'],
		briquettingSizePopupShow: false,
		briquettingSizeList: ['--', '680x340x140（长x宽x高,mm）', '680x340x210（长x宽x高,mm）', '其他'],
		subBriquettingSizePlaceholder: "请选择压块尺寸",
		subBriquettingSizeDisabled: true,
		briquettingWeightPopupShow: false,
		briquettingWeightList: ['--', '25公斤', '35公斤', '其他'],
		subBriquettingWeightPlaceholder: "请选择压块重量",
		subBriquettingWeightDisabled: true, 
		packFormPopupShow:false, 
		packFormList: ['--','薄膜包装+装袋+装箱+码垛','薄膜包装+装袋+码垛','薄膜包装+装袋+装箱','薄膜包装+装箱', '其他'],
		subPackFormPlaceholder: "请选择包装码垛形式",
		subPackFormDisabled: true, 

	},

	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function (options) {

	},

	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady: function () {

	},

	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow: function () {

	},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide: function () {

	},

	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload: function () {

	},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh: function () {

	},

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom: function () {

	},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage: function () {

	},

	ShowPopup(event) {
		// this.setData({
		// 	fluidityShow: true
		// });
		const { key } = event.currentTarget.dataset;
    this.setData({
      [key]: true,
    });
	},

	OnClose(event) {
		const { key } = event.currentTarget.dataset;
    this.setData({
      [key]: false,
    });
	},

	PickerOnChange(event) {
		const {
			picker,
			value,
			index
		} = event.detail;
		const { key } = event.currentTarget.dataset;
    this.setData({
      [key]: value,
    });
	},

	FieldOnChange(event){
		const { key } = event.currentTarget.dataset;
    this.setData({
      [key]: event.detail,
    });
	},

	envTempOnChange(event) {
		const {
			picker,
			value,
			index
		} = event.detail;
		this.setData({
			envTempRange: value
		});
		if (value == '其他温度') {
			this.setData({
				otherTempDisabled: false,
				otherTempPlaceholder: "请输入其他温度（数字）",
				otherTemp: null,
			});
		} else {
			this.setData({
				otherTempDisabled: true,
				otherTempPlaceholder: "此项不必填写",
				otherTemp: null,
			});
		};
	},


	dangerAreaOnChange(event) {
		const {
			picker,
			value,
			index
		} = event.detail;
		this.setData({
			dangerArea: value
		});
		if (value == '粉尘防爆区' || value == '气体防爆区') {
			this.setData({
				subDangerAreaDisabled: false,
				subDangerAreaLabel: value,
				subDangerAreaPlaceholder: "请输入具体区域（区域号）",
				subDangerArea: null,
			});
		} else if (value == '非防爆区') {
			this.setData({
				subDangerAreaPlaceholder: "非防爆区不必填写",
				subDangerAreaDisabled: true,
				subDangerArea: null,
				subDangerAreaLabel: "具体防爆区域"
			});
		} else if (value == '--') {
			this.setData({
				subDangerAreaPlaceholder: "无防爆区不必填写",
				subDangerAreaDisabled: true,
				subDangerArea: null,
				subDangerAreaLabel: "具体防爆区域"
			});
		}
	},


	briquettingSizeOnChange(event) {
		const { picker, value, index } = event.detail;
		this.setData({ briquettingSize: value });
		if (value == '其他') {
			this.setData({
				subBriquettingSizeDisabled: false,
				subBriquettingSizePlaceholder: "请输入尺寸（长x宽x高,mm）",
				subBriquettingSize: null,
			});
		} else {
			this.setData({
				subBriquettingSizePlaceholder: "已选择尺寸，不必填写",
				subBriquettingSizeDisabled: true,
				subBriquettingSize: null,
			});
		}
	},


	briquettingWeightOnChange(event){
		const {picker, value, index} = event.detail;
		this.setData({briquettingWeight: value});
		if (value == '其他') {
			this.setData({
				subBriquettingWeightDisabled: false,
				subBriquettingWeightPlaceholder: "请输入重量（公斤）",
				subBriquettingWeight: null,
			});
		} else {
			this.setData({
				subBriquettingWeightPlaceholder: "已选择重量，不必填写",
				subBriquettingWeightDisabled: true,
				subBriquettingWeight: null,
			});
		}
	},


	packFormOnChange(event){
		const { picker, value, index} = event.detail;
		this.setData({packForm: value});
		if (value == '其他') {
			this.setData({
				subPackFormDisabled: false,
				subPackFormPlaceholder: "包装码垛形式",
				subPackForm: null,
			});
		} else {
			this.setData({
				subPackFormPlaceholder: "已选择具体包装码垛形式，不必填写",
				subPackFormDisabled: true,
				subPackForm: null,
			});
		}
	},
	
	submitButtonOnClick() {

	},

})