import IMOperator from "../chat/im-operator.js";
import MsgManager from "../chat/msg-type/text-manager.js";
let code = ''
var verified = false
Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 调查结果变量
    companyName: null,  // 公司名称
    userName: null,     // 姓名
    phone: null,        // 手机
    ver_code: null,     // 验证码
    province: null,     // 省
    city: null,         // 市
 

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.msgManager = new MsgManager(this);
    this.imOperator = new IMOperator(this, {});
    var that = this
    // 查看是否存在缓存
    wx.getStorage({
      key: 'userInfo',
      success (res) {
        var data = JSON.parse(res.data);
        //let that = this
        that.setData({
          userName: data['姓名'],
          phone: data['手机'],
          province: data['省'],
          city: data['市']
        })
        
        verified = true
        wx.navigateTo({
          url: '../../pages/manual/manual?data='+res.data,
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  async sendMsg({content, itemIndex}) {
    try {
        const {msg} = await this.imOperator.onSimulateSendMsg({content})
        console.log(msg)
        return {msg};
    } catch (e) {
        console.log(e);
    }
},

  getVerCode(){
    code = ''
    if(this.data.phone.length != 11){
      wx.showToast({
        title: '请输入正确的手机号',
      })
      return
    }
    for (var i = 0; i < 4; i++) {
      code += Math.floor(Math.random() * 9);
    }

    wx.request({
      url: `https://api-v4.mysubmail.com/sms/xsend`,
      method: 'post',
      data: {
        'appid': '78557',
        'signature': '3e5d4121fbe460c176a280d63602e8f2',
        'vars': JSON.stringify({SMSCode: code}),
        'project': 'h7HF53',
        'to': this.data.phone
      },
      dataType: 'json',
      header: {
        'content-type': 'application/json',
        'accept': 'application/json'
      },
      success:(res) => {
        wx.showToast({
          title: '发送成功',
        })
        console.log('success', res)
      },
      fail:(res) => {
        console.log('failure', res)
      }
    })
  },

  showToast(msg){
    wx.showToast({
      title: msg,
      icon: 'none',
      duration: 2000
    })
  },

  onGatewayEvent(e) {
    console.log('gateway result', e.detail);
  },

  submitButtonOnClick(){
    if(verified){
      var data = {
        '姓名': this.data.userName,
        '手机': this.data.phone,
        '省': this.data.province,
        '市': this.data.city,
      }
      wx.navigateTo({
        url: '../../pages/manual/manual?data='+JSON.stringify(data),
      })
    }
    /*
      这里补提交按钮逻辑
    */
    else{
      var that = this;
      if(that.data.companyName == null || that.data.userName == null){
          that.showToast('请填写必填字段');
      }
      if (code == this.data.ver_code){
        that.showToast('验证正确');
        var data = {
          '姓名': that.data.userName,
          '手机': that.data.phone,
          '省': that.data.province,
          '市': that.data.city,
        }
        // var content = {key:'user-info', value:data}
        // this.msgManager.sendOneMsg({type:"user-info", content});
        // this.msgManager.sendOneMsg({type:"user-info", content});
        // wx.navigateTo({
        //   url: '../../pages/chat/chat',
        // })

        wx.setStorage({
          data: JSON.stringify(data),
          key: 'userInfo',
        })

        wx.navigateTo({
          url: '../../pages/manual/manual?data='+JSON.stringify(data),
        })
      } else {
        that.showToast('验证失败');
      }
    }
  },

})