const request = require('request');

module.exports = function () { 
    return { 
        helper:{
          testsend:  function(content){
                let url = `https://api-v4.mysubmail.com/sms/xsend`
                let options = {
                  method: 'post',
                  url: url,
                  json: {
                    'appid': '78557',
                    'signature': '3e5d4121fbe460c176a280d63602e8f2',
                    'vars': JSON.stringify(content),
                    'project':'tu9le3',
                    'to': '18655455369'
                  },
                  headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'  // 需指定这个参数 否则 在特定的环境下 会引起406错误
                  }
                }
                //
                request(options, function (err, res, body) {
                  if (err) {
                    console.log(err)
                  } else {
                    console.log(body)
                  }
                })
            },
          send: function(content,to,project){
            let url = `https://api-v4.mysubmail.com/sms/xsend`
            let options = {
              method: 'post',
              url: url,
              json: {
                'appid': '78557',
                'signature': '3e5d4121fbe460c176a280d63602e8f2',
                'vars': JSON.stringify(content),
                'project':project,
                'to': to
              },
              headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'  // 需指定这个参数 否则 在特定的环境下 会引起406错误
              }
            }
            //
            request(options, function (err, res, body) {
              if (err) {
                console.log(err)
              } else {
                console.log(body)
              }
            })
            }

        }
        
        
      
    }; 
};