Page(
  {
    data:{
    },

    onShow(){  
    },

    onReady: function () {
    },
  
    onLoad:function(options){
      this.send = options.data;
      this.send = JSON.parse(this.send);
      var keys = ['物料名称', '堆积密度', 'PH值', '安息角度', '流动性', '静电', '腐蚀性', '吸湿性', '粘附性', '毒性', '接触物料材质', '环境温度', '环境温度-其他','危险区域', '危险区域具体区号', '其他危险区域', '生产能力', '物料表面喷涂', '前端排雾设备', '干燥箱排风系统', '脱水筛出料含水率', '挤压脱水机出料含水率', '膨胀干燥机出料含水率', '挤压膨胀一体机出料含水率', '干燥箱出料含水率', '其他', '生产能力', '压块尺寸', '其他压块尺寸', '压块重量', '其他压块重量', '包装码垛形式', '其他包装码垛形式', '码垛能力', '包装能力', '其他设备参数']
      for(var key in keys){
        if(!this.send.hasOwnProperty(keys[key])){
          this.send[keys[key]] = null
        }
      }
      this.send = JSON.stringify(this.send)
    },

    open(e){
      console.log(e)
      var url
      var id = Number(e.currentTarget.id)
      switch (id) {
        case 1:
          wx.reLaunch({
            url: '../../pages/rubber_qs_mt/rubber_qs_mt?data='+this.send,
          })
          break;
        case 2:
          wx.reLaunch({
            url: '../../pages/rubber_qs_dry/rubber_qs_dry?data='+this.send,
          })
          break
        case 3:
          wx.reLaunch({
            url: '../../pages/rubber_qs_craft/rubber_qs_craft?data='+this.send,
          })
          break
        case 4:
          wx.redirectTo({
            url: '../../pages/manual/manual',
          })
          break
        case 5:
          url = 'http://152.136.126.194/并线输送电气分册（二并一）.doc'
          break
        case 6:
          url = 'http://152.136.126.194/并线输送电气分册（三并一）.doc'
          break
        case 7:
          url = 'http://152.136.126.194/单摆臂包装电气分册.doc'
          break
        case 8:
          url = 'http://152.136.126.194/单抓单码(装箱)电气分册.doc'
          break
        case 9:
          url = 'http://152.136.126.194/单抓单码电气分册(第二版).doc'
          break
        case 10:
          url = 'http://152.136.126.194/低位码垛电气分册.doc'
          break
        case 11:
          url = 'http://152.136.126.194/封口机.doc'
          break
        case 12:
          url = 'http://152.136.126.194/拉伸套膜电气分册.doc'
          break
        case 13:
          url = 'http://152.136.126.194/输送检测电气分册.doc'
          break
        case 14:
          url = 'http://152.136.126.194/小车横进包装电气分册.doc'
          break
        default:
          break;
      }
    }  
  },
 )