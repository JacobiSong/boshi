Page({
  data: {
     url: 'https://www.boshi.cn/product/5'
  },
  onLoad: function(options){
      options.url ? this.setData({url: options.url}) : wx.navigateBack({delta: 2});
  }
});