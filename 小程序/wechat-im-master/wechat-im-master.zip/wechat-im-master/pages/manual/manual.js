const { justSimpleDealTime } = require("../../utils/time");
let data = ''

Page(
  {

    data:{
    },

    onShow(){  
    },

    onReady: function () {
    },
  
    onLoad:function(options){
      this.send = options.data;
      wx.getStorage({
        key: 'userInfo',
        success(res){
          data = res.data
        }
      })
      if(data != ''){
        this.send = data
      }
      console.log(this.send)
    },

    open(e){
      console.log(e)
      var url
      var id = Number(e.currentTarget.id)
      // this.send = {'name': '1'}
      // this.send = JSON.stringify(this.send)
      switch (id) {
        case 1:
          wx.reLaunch({
            url: '../../pages/menu1/menu1?data='+this.send,
          })
          break;
        case 2:
          wx.reLaunch({
            url: '../../pages/menu2/menu2?data='+this.send,
          })
          break
        case 3:
          wx.reLaunch({
            url: '../../pages/web_/web_',
          })
          break
        case 4:
          wx.reLaunch({
            url: '../../pages/chat/chat',
          })
          break
        case 5:
          url = 'http://152.136.126.194/并线输送电气分册（二并一）.doc'
          break
        case 6:
          url = 'http://152.136.126.194/并线输送电气分册（三并一）.doc'
          break
        case 7:
          url = 'http://152.136.126.194/单摆臂包装电气分册.doc'
          break
        case 8:
          url = 'http://152.136.126.194/单抓单码(装箱)电气分册.doc'
          break
        case 9:
          url = 'http://152.136.126.194/单抓单码电气分册(第二版).doc'
          break
        case 10:
          url = 'http://152.136.126.194/低位码垛电气分册.doc'
          break
        case 11:
          url = 'http://152.136.126.194/封口机.doc'
          break
        case 12:
          url = 'http://152.136.126.194/拉伸套膜电气分册.doc'
          break
        case 13:
          url = 'http://152.136.126.194/输送检测电气分册.doc'
          break
        case 14:
          url = 'http://152.136.126.194/小车横进包装电气分册.doc'
          break
        default:
          break;
      }
    }  
  },
 )