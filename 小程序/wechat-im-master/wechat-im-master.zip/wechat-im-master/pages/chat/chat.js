// pages/list/list.js
import IMOperator from "./im-operator";
import UI from "./ui";
import MsgManager from "./msg-manager";
import time from "../../utils/time";
import {justSimpleDealTime} from "../../utils/time";
var name = ''
var chatItems=[]
var showed = false
/**
 * 聊天页面
 */
Page({

    /**
     * 页面的初始数据
     */
    data: {
        textMessage: '',
        chatCustom:[],
        chatItems: [],
        latestPlayVoicePath: '',
        chatStatue: 'open',
        extraArr: [{
            picName: 'choose_picture',
            description: '产品售前'
        }, {
            picName: 'take_photos',
            description: '故障查询'
        }],
    },

    generateMixed(n) {
        let chars = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
        let res = "";
        for (var i = 0; i < n; i++) {
          var id = Math.ceil(Math.random() * 35);
          res += chars[id];
        }
        return res;
      },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        // this.name = ''
        var value = wx.getStorageSync('key')
        if(!value){
            name = this.generateMixed(16)
            wx.setStorage({
                key: "key",
                data: name
            })
        }else{
            wx.getStorage({
                key: 'key',
                success: function (data) {
                  name = data['data']
                }
              })
        }
        
        const friend = {friendId: 0,
            userId: 'user_001',
            nickName: '柳如月',
            myHeadUrl: 'http://downza.img.zz314.com/edu/pc/wlgj-1008/2016-06-23/64ec0888b15773e3ba5b5f744b9df16c.jpg'
        };

        // this.showed = false
        
        
        // console.log(friend);
      
        // this.setData({
        //     pageHeight: wx.getSystemInfoSync().windowHeight,
        // });
        wx.setNavigationBarTitle({
            title: friend.friendName || ''
        });
        this.imOperator = new IMOperator(this, friend);
        this.UI = new UI(this);
        // console.log(this.name)
        this.msgManager = new MsgManager(this);

        this.imOperator.onSimulateReceiveMsg((msg) => {
            this.msgManager.showMsg({msg})
        });
        this.UI.updateChatStatus('正在聊天中...');
        if(options.name){
            name = options.name
            this.name = name
        }

        var height = wx.getSystemInfoSync().windowHeight;
        this.setData({
            chatItems: chatItems.sort(UI._sortMsgListByTimestamp),
            scrollTopVal: chatItems.length * 1000,
            height:height
        });
        
    },
    onReady() {
        this.chatInput = this.selectComponent('#chatInput');
    },

    onShow(){
        var t = Date.now()
        const time = justSimpleDealTime(t, false)
        var msg = {
            isMy:false,
            msgId: 0,
            friendId: 0,
            showTime:true,
            timestamp:t,
            timestr: time.timestr,
            type:'text',
            headUrl:"other_head.jpg",
            content:{
                answer: '',
                label:'猜您想问(请点击查看)',
                // label: '',
                question: "尊敬的客户您好，小博为您服务",
                related_question:[
                    {textt:'售前下单', text:'售前下单'},
                ]
            }
        }
        if(!showed){
            this.UI._page.data.chatItems.push(msg);
            showed = true;
        }
        // console.log(chatItems)
        if(chatItems.length > 0){
            this.UI._page.setData({
                chatItems: chatItems,
                scrollTopVal: this.UI._page.data.chatItems.length * 999,
            });
        }else{
            this.UI._page.setData({
                chatItems: this.UI._page.data.chatItems,
                scrollTopVal: this.UI._page.data.chatItems.length * 999,
            });
        }
    },

    onSendMessageEvent(e) {
        if(this.chatInput.data.inputValueEventTemp == ""){
            this.chatInput.data.inputValueEventTemp = e.detail.value
        }
        let content = {type:'ans', value:this.chatInput.data.inputValueEventTemp, user:name};
        this.msgManager.sendMsg({type: IMOperator.TextType, content});
        this.chatInput.data.inputValueEventTemp = ""
    },
    onSendUserName(e) {
        let content = {value:e.detail.value, user:name};
        this.msgManager.sendMsg({type: 'voice', content});
    },
    // TODO: 需要改的地方在这里了
    onSendMyMessageEvent(e) {
        var content = {type: 'key', value: e.detail.value}
        this.data.inputValueEventTemp = '';
        console.log(content)
        this.msgManager.sendMsg({type: IMOperator.TextType, content});
    },

    onVoiceRecordEvent(e) {
        const {detail: {recordStatus, duration, tempFilePath, fileSize,}} = e;
        if (recordStatus === 2) {
            this.msgManager.sendMsg({
                type: IMOperator.VoiceType,
                content: tempFilePath,
                duration: Math.floor(duration / 1000)
            });
        }
        this.msgManager.stopAllVoice();
    },
    /**
     * 点击extra中的item时触发
     * @param e
     */
    onExtraItemClickEvent(e) {
        console.warn(e);
        let chooseIndex = parseInt(e.detail.index);
        // console.log('here to choose ')
        // console.log(chooseIndex)
        
        // if (chooseIndex === 2) {
        //     this.myFun();
        //     return;
        // }
        // wx.chooseImage({
        //     count: 1, // 默认9
        //     sizeType: ['compressed'],
        //     sourceType: chooseIndex === 0 ? ['album'] : ['camera'],
        //     success: (res) => {
        //         this.msgManager.sendMsg({type: IMOperator.ImageType, content: res.tempFilePaths[0]})
        //     }
        // });
        wx.showModal({
            title: '功能未开发',
            content: '敬请期待',
            // confirmText: '去设置',
        })
    },
    /**
     * 点击extra按钮时触发
     * @param e
     */
    onExtraClickEvent(e) {
        console.log(e);
    },
    //模拟上传文件，注意这里的cbOk回调函数传入的参数应该是上传文件成功时返回的文件url，这里因为模拟，我直接用的savedFilePath
    simulateUploadFile({savedFilePath, duration, itemIndex}) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                let urlFromServerWhenUploadSuccess = savedFilePath;
                resolve({url: urlFromServerWhenUploadSuccess});
            }, 1000);
        });
    },

    /**
     * 自定义事件
     */
    myFun(e) {
        // console.log('here')
        console.log(e.detail.path)
        console.log(e.detail.query)   
    },

    handleContact (e) {
        console.log(e.detail.path)
        console.log(e.detail.query)
    },

    resetInputStatus() {
        this.chatInput.closeExtraView();
    },

    onUnload() {
        this.msgManager.stopAllVoice();
    },
    // 这里也需要修改
    async sendMsg({content, itemIndex}) {
        // console.log(e)
        // console.log(content)
        // console.log('zhushi')
        try {
            if (this.UI.last_received_msg){
                let msgs = this.UI.last_received_msg.content.related_question
                if(msgs.length > 0){
                    if(Number(content.content) && Number(content.content) <= msgs.length){
                        content.content = {type:'ans', value: msgs[Number(content.content)-1].text}
                    }   
                }
            }
            const {msg} = await this.imOperator.onSimulateSendMsg({content})
            console.log(msg)
            this.UI.updateViewWhenSendSuccess(msg, itemIndex);
            chatItems = this.UI._page.data.chatItems
            // console.log(chatItems)
            return {msg};
        } catch (e) {
            console.log(e);
            this.UI.updateViewWhenSendFailed(itemIndex);
        }
    },

    show_message(e) {
        this.data.inputValueEventTemp = this.UI.last_received_msg.content.related_question[e.currentTarget.id -1].text
        this.chatInput.data.inputValueEventTemp =  this.data.inputValueEventTemp
        this.chatInput.setData({
            textMessage: this.data.inputValueEventTemp
        })
    },
    /**
     * 重发消息
     * @param e
     */
    resendMsgEvent(e) {
        const itemIndex = parseInt(e.currentTarget.dataset.resendIndex);
        const item = this.data.chatItems[itemIndex];
        this.UI.updateDataWhenStartSending(item, false, false);
        this.msgManager.resend({...item, itemIndex});
    },
});
