import FileManager from "./base/file-manager";

export default class ImageManager extends FileManager {
    constructor(page) {
        super(page);
        this._page.imageClickEvent = function (e) {
            if(e.currentTarget.dataset.url.answer){
                wx.previewImage({
                    current: e.currentTarget.dataset.url.answer, // 当前显示图片的http链接
                    urls: [e.currentTarget.dataset.url.answer] // 需要预览的图片http链接列表
                })
                console.log('e.currentTarget.dataset.url')
                console.log(e.currentTarget.dataset)
            }else{
                wx.previewImage({
                    current: e.currentTarget.dataset.url, // 当前显示图片的http链接
                    urls: [e.currentTarget.dataset.url] // 需要预览的图片http链接列表
                })
            }
        }

        // this.page.imageClickEvent1 = function (e) {
        //     wx.previewImage({
        //         current:e.currentTarget.dataset,
        //         urls: [e.currentTarget.dataset]
        //     })
        //     console.log('e.currentTarget.dataset.url')
        //     console.log(e.currentTarget.dataset)
        // }
    }
}