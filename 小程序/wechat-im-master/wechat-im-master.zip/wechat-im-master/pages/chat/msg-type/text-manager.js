var name = ''
// import verified from "../../client-info/client-info.js";
var verified = false
export default class TextManager {
    constructor(page) {
        
        this._page = page;
        this.name = '';
        // console.log(this._page)
        var value = wx.getStorageSync('key')
        if(value){
            wx.getStorage({
                key: 'key',
                success: function (data) {
                  name =  data['data']
                }
              })
        }
        this._page.send_message = async (e) => {
            // console.log('herererererere')
            if (e.currentTarget.id != 'chatInput'){
                // var v = 
                // console.log('vbhjafbvhksgdfwvsfdhsafyg')
                if(e.currentTarget.id == '售前下单'){
                    wx.getStorage({
                        key: 'userInfo',
                        success (res) {
                            verified = true
                            wx.navigateTo({
                                url: '../../pages/manual/manual?data='+res.data,
                            })
                        }
                    })
                    if(!verified){
                        wx.navigateTo({
                        url: '../../pages/client-info/client-info',
                      })
                    }
                }else{
                    // console.log(e.currentTarget.id)
                    // console.log(name)
                    this.sendOneMsg({content: {type:'ans', value:e.currentTarget.id, 'user': name},  type:'text', e})
                }
            }
        }
    }

    /**
     * 接收到消息时，通过UI类的管理进行渲染
     * @param msg 接收到的消息，这个对象应是由 im-operator.js 中的createNormalChatItem()方法生成的。
     */
    showMsg({msg}) {
        //UI类是用于管理UI展示的类。
        this._page.UI.updateViewWhenReceive(msg);
    }

    /**
     * 发送消息时，通过UI类来管理发送状态的切换和消息的渲染
     * @param content 输入组件获取到的原始文本信息
     * @param type
     */
   async sendOneMsg({content, type}) {
    console.log({content, type})
    console.log(this._page)
    // console.log(this._page.UI)
    // console.log(this._page.UI.last_received_msg.content)
    if(this._page.UI != null){
        const {itemIndex} = await this._page.UI.showItemForMoment(this._page.imOperator.createNormalChatItem({
                type,
                content
        }));
            let p =  this._page.imOperator.createChatItemContent({type, content})
            this._page.sendMsg({
                content: p,
                itemIndex
            });
    }else{
        const itemIndex = 0
        let p =  this._page.imOperator.createChatItemContent({type, content})
            this._page.sendMsg({
                content: p,
                itemIndex
            });
    }
    }

    resend({type, content, duration, itemIndex}) {
        this._page.sendMsg({
            content: this._page.imOperator.createChatItemContent({
                type,
                content,
                duration
            }),
            itemIndex,
            success: (msg) => {
                this._page.UI.updateListViewBySort();
            }
        });
    }
}
