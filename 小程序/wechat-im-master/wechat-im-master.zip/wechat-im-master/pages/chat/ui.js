/**
 * 用户处理消息的收发UI更新
 */
export default class UI {
    constructor(page) {
        this._page = page;
        this.received_msg = false;
        this.last_received_msg = false;
    }

    /**
     * 接收到消息时，更新UI
     * @param msg
     */
    updateViewWhenReceive(msg) {
        msg.isMy = false
        msg.headUrl = "other_head.jpg"
        console.log(msg)
        this.last_received_msg = msg;
        console.log('received massage:')
        console.log(msg)
        this.received_msg = true
        this._page.data.chatItems.push(msg);
        var height = wx.getSystemInfoSync().windowHeight;
        this._page.setData({
            chatItems: this._page.data.chatItems.sort(UI._sortMsgListByTimestamp),
            scrollTopVal: this._page.data.chatItems.length * 1000,
            // toView: 'item${this._page.data.chatItems.length - 1}'
            height:height
        });
    }

    updateViewWhenReceive1(msg) {
        msg.isMy = false
        msg.headUrl = "other_head.jpg"
        this.last_received_msg = msg;
        this.received_msg = true
        this._page.data.chatItems.push(msg)
        var height = wx.getSystemInfoSync().windowHeight;
        this._page.setData({
            chatItems: this._page.data.chatItems.sort(UI._sortMsgListByTimestamp),
            scrollTopVal: this._page.data.chatItems.length * 1000,
            // toView: 'item${this._page.data.chatItems.length - 1}'
            height:height
        });
        this._page.data.chatItems.pop()
    }

    /**
     * 发送消息时，渲染消息的发送状态为 发送中
     * @param sendMsg
     */
    async showItemForMoment(sendMsg) {
        if (!sendMsg) return;
        // 注释掉下边的这一条时，不会显示对话框
        console.log(sendMsg)
        console.log('showItem')
        // console.log(this._page.UI.last_received_msg)
        // let msg = sendMsg.content
        // sendMsg.content = {type: 'ans', value: '产品'}
        // if (this._page.UI.last_received_msg){
        //     let msgs = this._page.UI.last_received_msg.content.related_question
        //     console.log(msgs)
        //     if(msgs.length > 0){
        //         if(Number(sendMsg.content) && Number(sendMsg.content) <= msgs.length){
        //             sendMsg.content = {type:'ans', value: msgs[Number(sendMsg.content)-1].text}
        //         }   
        //     }
        // }else{
        //     var co = sendMsg.content
        //     sendMsg.content = {type: 'key', value: co}
        // }
        if(sendMsg.content.type == 'ans'){
            // console.log('我在这里')
            // console.log(sendMsg)
            this.updateDataWhenStartSending(sendMsg);
        }
        return {itemIndex: this._page.data.chatItems.length - 1};
    }

    /**
     * 设置消息发送状态为 发送中
     * @param sendMsg
     * @param addToArr
     * @param needScroll
     */
    updateDataWhenStartSending(sendMsg, addToArr = true, needScroll = true) {
        // console.log('nvjefvjfvbajdfbvjbfvj')
        
        this._page.chatInput.closeExtraView();
        sendMsg.sendStatus = 'sending';
        addToArr && this._page.data.chatItems.push(sendMsg);
        let obj = {};
        obj['textMessage'] = '';
        obj['chatItems'] = this._page.data.chatItems;
        needScroll && (obj['scrollTopVal'] = this._page.data.chatItems.length * 999);
        this._page.setData(obj);
    }

    /**
     * 设置消息发送状态为 发送成功
     * @param sendMsg
     * @param itemIndex
     */
    updateViewWhenSendSuccess(sendMsg, itemIndex) {
        let that = this._page;
        let item = that.data.chatItems[itemIndex];
        item.timestamp = sendMsg.timestamp;
        this.updateSendStatusView('success', itemIndex);
    }

    updateListViewBySort() {
        this._page.setData({
            chatItems: this._page.data.chatItems.sort(UI._sortMsgListByTimestamp)
        })
    }

    /**
     * 设置消息发送状态为 发送失败
     * @param itemIndex
     */
    updateViewWhenSendFailed(itemIndex) {
        this.updateSendStatusView('failed', itemIndex);
    }

    updateSendStatusView(status, itemIndex) {
        let that = this._page;
        that.data.chatItems[itemIndex].sendStatus = status;
        let obj = {};
        obj[`chatItems[${itemIndex}].sendStatus`] = status;
        that.setData(obj);
    }

    updateChatStatus(content, open = true) {
        this._page.setData({
            chatStatue: open ? 'open' : 'close',
            chatStatusContent: content
        })
    }

    static _sortMsgListByTimestamp(item1, item2) {
        return item1.timestamp - item2.timestamp;
    }
}
