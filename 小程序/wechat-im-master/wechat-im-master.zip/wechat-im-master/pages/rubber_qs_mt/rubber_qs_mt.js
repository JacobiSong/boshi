// pages/questionnaire/questionnaire.js
import IMOperator from "../chat/im-operator.js";
import MsgManager from "../chat/msg-type/text-manager.js";
Page({

	/**
	 * 页面的初始数据
	 */
	data: {

		// 调查结果变量

		
		// 二、物料参数
		materielName: null,	//物料名称	
		bulkDensity: null,	//堆积密度
		ph: null,			//PH值
		degree: null,		//安息角度		
		fluidity: null,			//流动性
		staElec: null,			//静电
		causticity: null,		//腐蚀性
		hygroscopic: null,		//吸湿性
		adhesion: null,			//粘附性
		toxicity: null,			//毒性
		contactMaterial: null,	//接触物料材质
		envTempRange: null,		//环境温度
		otherTemp: null,		//环境温度-其他	
		dangerArea: null,		//危险区域
		subDangerArea: null,	//危险区域具体区号 
		otherDangerArea: null,	//其他危险区域

		




		// 页面 变量
		materielStatusShow: false,
		materielStatusList: ['--', '颗粒状', '粉状', '超粉状', '片状', '晶体'],
		fluidityShow: false,
		fluidityList: ['--', '好', '一般', '差'],
		staElecShow: false,
		staElecList: ['--', '强', '弱', '无'],
		causticityShow: false,
		hygroscopicShow: false,
		toxicityShow: false,
		causticityList: ['--', '否', '弱', '中', '强'],
		adhesionShow: false,
		adhesionList: ['--', '否', '弱', '中', '强', '结块'],
		contactMaterialShow: false,
		contactMaterialList: ['--', 'SS304', 'SS316', 'SS316L', '其他'],
		envTempShow: false,
		envTempList: ['--', '5ºC~40ºC', '-20ºC~40ºC', '其他温度'],
		otherTempPlaceholder: "请先选择环境温度",
		otherTempDisabled: true,
		dangerAreaShow: false,
		dangerAreaList: ['--', '非防爆区', '粉尘防爆区', '气体防爆区'],
		subDangerAreaLabel: '具体防爆区域',
		subDangerAreaPlaceholder: '请先选择危险区域',
		subDangerAreaDisabled: true,
		otherDangerAreaShow: false,
		otherDangerAreaList: ['--', '污染会影响产品质量', '含油性会影响橡胶的化学性能'],
		
	},

	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function (options) {
    this.msgManager = new MsgManager(this);
		this.imOperator = new IMOperator(this, {});
		this.send = JSON.parse(options.data);
		var that = this
		wx.getStorage({
			key: 'rubber_mt',
			success(res){
				var data = JSON.parse(res.data)
				that.setData({
					materielName:data['物料名称'],	//物料名称	
					bulkDensity:data['堆积密度'],	//堆积密度
					ph:data['PH值'],			//PH值
					degree:data['安息角度'],		//安息角度		
					fluidity:data['流动性'],			//流动性
					staElec:data['静电'],			//静电
					causticity:data['腐蚀性'],		//腐蚀性
					hygroscopic:data['吸湿性'],		//吸湿性
					adhesion:data['粘附性'],			//粘附性
					toxicity:data['毒性'],			//毒性
					contactMaterial:data['接触物料材质'],	//接触物料材质
					envTempRange:data['环境温度'],		//环境温度
					otherTemp:data['环境温度-其他'],		//环境温度-其他	
					dangerArea:data['危险区域'],		//危险区域
					subDangerArea:data['危险区域具体区号'],	//危险区域具体区号 
					otherDangerArea:data['其他危险区域']	//其他危险区域
				})
			}
		})
	},

	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady: function () {

	},

	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow: function () {

	},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide: function () {

	},

	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload: function () {

	},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh: function () {

	},

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom: function () {

	},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage: function () {

	},

	ShowPopup(event) {
		// this.setData({
		// 	fluidityShow: true
		// });
		const { key } = event.currentTarget.dataset;
    this.setData({
      [key]: true,
    });
	},

	OnClose(event) {
		const { key } = event.currentTarget.dataset;
    this.setData({
      [key]: false,
    });
	},

	PickerOnChange(event) {
		const {
			picker,
			value,
			index
		} = event.detail;
		const { key } = event.currentTarget.dataset;
    this.setData({
      [key]: value,
    });
	},

	FieldOnChange(event){
		const { key } = event.currentTarget.dataset;
    this.setData({
      [key]: event.detail,
    });
	},

	envTempOnChange(event) {
		const {
			picker,
			value,
			index
		} = event.detail;
		this.setData({
			envTempRange: value
		});
		if (value == '其他温度') {
			this.setData({
				otherTempDisabled: false,
				otherTempPlaceholder: "请输入其他温度（数字）",
				otherTemp: null,
			});
		} else {
			this.setData({
				otherTempDisabled: true,
				otherTempPlaceholder: "此项不必填写",
				otherTemp: null,
			});
		};
	},


	dangerAreaOnChange(event) {
		const {
			picker,
			value,
			index
		} = event.detail;
		this.setData({
			dangerArea: value
		});
		if (value == '粉尘防爆区' || value == '气体防爆区') {
			this.setData({
				subDangerAreaDisabled: false,
				subDangerAreaLabel: value,
				subDangerAreaPlaceholder: "请输入具体区域（区域号）",
				subDangerArea: null,
			});
		} else if (value == '非防爆区') {
			this.setData({
				subDangerAreaPlaceholder: "非防爆区不必填写",
				subDangerAreaDisabled: true,
				subDangerArea: null,
				subDangerAreaLabel: "具体防爆区域"
			});
		} else if (value == '--') {
			this.setData({
				subDangerAreaPlaceholder: "无防爆区不必填写",
				subDangerAreaDisabled: true,
				subDangerArea: null,
				subDangerAreaLabel: "具体防爆区域"
			});
		}
	},


	briquettingSizeOnChange(event) {
		const { picker, value, index } = event.detail;
		this.setData({ briquettingSize: value });
		if (value == '其他') {
			this.setData({
				subBriquettingSizeDisabled: false,
				subBriquettingSizePlaceholder: "请输入尺寸（长x宽x高,mm）",
				subBriquettingSize: null,
			});
		} else {
			this.setData({
				subBriquettingSizePlaceholder: "已选择尺寸，不必填写",
				subBriquettingSizeDisabled: true,
				subBriquettingSize: null,
			});
		}
	},


	briquettingWeightOnChange(event){
		const {picker, value, index} = event.detail;
		this.setData({briquettingWeight: value});
		if (value == '其他') {
			this.setData({
				subBriquettingWeightDisabled: false,
				subBriquettingWeightPlaceholder: "请输入重量（公斤）",
				subBriquettingWeight: null,
			});
		} else {
			this.setData({
				subBriquettingWeightPlaceholder: "已选择重量，不必填写",
				subBriquettingWeightDisabled: true,
				subBriquettingWeight: null,
			});
		}
	},


	packFormOnChange(event){
		const { picker, value, index} = event.detail;
		this.setData({packForm: value});
		if (value == '其他') {
			this.setData({
				subPackFormDisabled: false,
				subPackFormPlaceholder: "包装码垛形式",
				subPackForm: null,
			});
		} else {
			this.setData({
				subPackFormPlaceholder: "已选择具体包装码垛形式，不必填写",
				subPackFormDisabled: true,
				subPackForm: null,
			});
		}
	},
	
	async sendMsg({content, itemIndex}) {
    try {
        const {msg} = await this.imOperator.onSimulateSendMsg({content})
        console.log(msg)
        return {msg};
    } catch (e) {
        console.log(e);
    }
},

	submitButtonOnClick() {
		this.send['物料名称'] = this.data.materielName,	//物料名称	
		this.send['堆积密度'] = this.data.bulkDensity,	//堆积密度
		this.send['PH值'] = this.data.ph,			//PH值
		this.send['安息角度'] = this.data.degree,		//安息角度		
		this.send['流动性'] = this.data.fluidity,			//流动性
		this.send['静电'] = this.data.staElec,			//静电
		this.send['腐蚀性'] = this.data.causticity,		//腐蚀性
		this.send['吸湿性'] = this.data.hygroscopic,		//吸湿性
		this.send['粘附性'] = this.data.adhesion,			//粘附性
		this.send['毒性'] = this.data.toxicity,			//毒性
		this.send['接触物料材质'] = this.data.contactMaterial,	//接触物料材质
		this.send['环境温度'] = this.data.envTempRange,		//环境温度
		this.send['环境温度-其他'] = this.data.otherTemp,		//环境温度-其他	
		this.send['危险区域'] = this.data.dangerArea,		//危险区域
		this.send['危险区域具体区号'] = this.data.subDangerArea,	//危险区域具体区号 
		this.send['其他危险区域'] = this.data.otherDangerArea	//其他危险区域

		wx.setStorage({
			data: JSON.stringify(this.send),
			key: 'rubber_mt',
		})

		var content = {key:'rubber-info', value:this.send}
		this.msgManager.sendOneMsg({type:"user-info", content});
		wx.reLaunch({
			url: '../../pages/menu1/menu1?data='+JSON.stringify(this.send)
		})
	},

})