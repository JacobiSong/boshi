const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
})

exports.main = async (event, context) => {
  try {
    const result = await cloud.openapi.cloudbase.sendSms({
        "env": 'sendsms-5gyxi24r20ea70e2',
        "smsType": 'Notification',
        "phoneNumberList": [
          "+86" + event.phone
        ],
        "templateId": '10000002',
        "templateParamList": [
          event.code
        ]
      })
    console.log(event)
    return result
  } catch (err) {
    console.log(event)
    return err
  }
}